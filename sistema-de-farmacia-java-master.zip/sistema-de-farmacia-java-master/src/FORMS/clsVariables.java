package FORMS;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */



/**
 *
 * @author Anita
 */
public class clsVariables {

    private int cod;
    private String nombre;

    public void Cod(int valor)
    {
        cod=valor;
    }
    public int Cod()
    {
        return cod;
    }
    public void Nombre(String valor)
    {
        nombre=valor;
    }
    public String Nombre()
    {
        return nombre;
    }


}
