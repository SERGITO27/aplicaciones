
package LOGIN;

/**
 *
 * @author Adolfo
 */
public class FARMACOM {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Login l = new Login();
        l.setVisible(true);
    }
    
}
